# SaveFrom.net-style Clone (Legal)

This is a SaveFrom.net-style **frontend clone** that **does not download videos**.  
It uses the **YouTube Data API v3** (public API key in the client) to fetch video metadata and provides official YouTube links and embeds.

**Important**
- Replace `PUBLIC_API_KEY` in `pages/index.js` with your own restricted API key.
- Do NOT use this app to download copyrighted content. This app only shows metadata and official YouTube links.

## Run locally
1. Install dependencies:
   ```
   npm install
   ```
2. Replace the API key placeholder in `pages/index.js`.
3. Run:
   ```
   npm run dev
   ```
4. Open http://localhost:3000

## Deploy
- Push to GitHub and deploy to Vercel. Make sure you restrict the API key to your domain.

