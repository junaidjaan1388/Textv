import { useState } from 'react';
import axios from 'axios';

/**
 * SaveFrom-style frontend (LEGAL): Fetches metadata using client-side YouTube Data API v3.
 * Replace PUBLIC_API_KEY with your own restricted key.
 */

const PUBLIC_API_KEY = "YOUR_PUBLIC_API_KEY_HERE"; // <<-- REPLACE THIS with a restricted public API key

export default function Home() {
  const [input, setInput] = useState('');
  const [video, setVideo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function extractVideoId(urlOrId) {
    if (!urlOrId) return null;
    // direct id
    const idRegex = /^[a-zA-Z0-9_-]{11}$/;
    if (idRegex.test(urlOrId)) return urlOrId;
    // url patterns
    const m = urlOrId.match(/(?:v=|youtu\.be\/|youtube.com\/embed\/)([a-zA-Z0-9_-]{11})/);
    return m ? m[1] : null;
  }

  async function fetchById(id) {
    setLoading(true);
    setError('');
    setVideo(null);
    try {
      const url = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,player&id=${id}&key=${PUBLIC_API_KEY}`;
      const res = await axios.get(url);
      if (res.data.items && res.data.items.length > 0) {
        setVideo(res.data.items[0]);
      } else {
        setError('Video not found or API quota exhausted.');
      }
    } catch (e) {
      console.error(e);
      setError('API error. Check your key and quota.');
    } finally {
      setLoading(false);
    }
  }

  async function onSubmit(e) {
    e && e.preventDefault();
    setError('');
    const id = extractVideoId(input.trim());
    if (!id) {
      setError('Please paste a valid YouTube URL or video ID.');
      return;
    }
    await fetchById(id);
  }

  return (
    <div style={{ fontFamily: 'system-ui, -apple-system, Roboto, "Segoe UI", Arial', padding: 24, maxWidth: 900, margin: '0 auto' }}>
      <h1 style={{ marginBottom: 6 }}>SaveFrom-style (Viewer clone)</h1>
      <p style={{ color: '#555', marginTop: 0 }}>Paste a YouTube link or ID — this viewer shows metadata and official links (no downloads).</p>

      <form onSubmit={onSubmit} style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="https://www.youtube.com/watch?v=... or video ID"
          style={{ flex: 1, padding: '12px 14px', fontSize: 16, borderRadius: 8, border: '1px solid #ddd' }}
        />
        <button type="submit" style={{ padding: '12px 16px', fontSize: 16, borderRadius: 8, cursor: 'pointer' }} disabled={loading}>
          {loading ? 'Loading…' : 'Fetch'}
        </button>
      </form>

      {error && <div style={{ marginTop: 12, color: 'crimson' }}>{error}</div>}

      {video && (
        <div style={{ marginTop: 20, display: 'grid', gridTemplateColumns: '320px 1fr', gap: 20, alignItems: 'start' }}>
          <div>
            <img src={video.snippet.thumbnails.maxres?.url || video.snippet.thumbnails.high?.url || video.snippet.thumbnails.default.url} alt={video.snippet.title} style={{ width: '100%', borderRadius: 8 }} />
            <div style={{ marginTop: 12 }}>
              <a
                href={`https://www.youtube.com/watch?v=${video.id}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: 'inline-block', padding: '10px 14px', borderRadius: 6, background: '#ff0000', color: '#fff', textDecoration: 'none' }}
              >
                Open on YouTube
              </a>
              <button
                onClick={() => {
                  navigator.clipboard && navigator.clipboard.writeText(`https://www.youtube.com/watch?v=${video.id}`);
                  alert('YouTube link copied to clipboard');
                }}
                style={{ marginLeft: 8, padding: '10px 14px', borderRadius: 6 }}
              >
                Copy Link
              </button>
            </div>
          </div>

          <div>
            <h2 style={{ margin: '0 0 6px 0' }}>{video.snippet.title}</h2>
            <p style={{ margin: '0 0 12px 0', color: '#666' }}>{video.snippet.channelTitle} • Published {new Date(video.snippet.publishedAt).toLocaleDateString()}</p>

            <div style={{ marginBottom: 12 }}>
              <strong>Description</strong>
              <div style={{ maxHeight: 160, overflow: 'auto', padding: 8, border: '1px solid #eee', borderRadius: 6, background: '#fafafa', marginTop: 8 }}>
                {video.snippet.description || '(no description)'}
              </div>
            </div>

            <div style={{ marginBottom: 12 }}>
              <strong>Preview</strong>
              <div style={{ marginTop: 8 }}>
                <iframe
                  title="preview"
                  width="560"
                  height="315"
                  src={`https://www.youtube.com/embed/${video.id}`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  style={{ width: '100%', borderRadius: 8 }}
                />
              </div>
            </div>

            <div>
              <strong>Formats & Actions</strong>
              <p style={{ color: '#555' }}>This app does not provide direct file downloads. Use the official YouTube page to download if permitted.</p>
              <ul>
                <li>Watch on YouTube (official)</li>
                <li>Open embed (in new tab)</li>
                <li>Copy link</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      <footer style={{ marginTop: 36, color: '#888' }}>
        Note: This is a legal viewer clone. It does NOT download video files and adheres to YouTube's Terms.
      </footer>
    </div>
  );
}
